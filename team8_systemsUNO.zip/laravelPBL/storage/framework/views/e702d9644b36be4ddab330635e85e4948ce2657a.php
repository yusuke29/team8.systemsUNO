<!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="<?php echo e(('css/participant.css')); ?>">
        <title>A008</title>
    </head>
    <header class="header">
        <p>岡山情報ビジネス学院<br>オープンキャンパス参加者情報入力フォーム</p>
    </header>
    <body>
    <a href="A007"><input type="button" class="back" value="☜前画面へ戻る"></a>
        <u><p style="margin-left: 45px;margin-top: 100px;font-size: 20px;">２週間以内に県外へ移動しましたか？</p></u>
        <div class="yn">
            <a href="/team8.systemsUNO/laravelPBL/public/A009"><button type="button" class="botton_1" id="move_yes">はい</button></a>
            <a href="/team8.systemsUNO/laravelPBL/public/A010"><button type="button" class="botton_2" id="move_no">いいえ</button></a>
        </div>
    </body>
</html><?php /**PATH C:\xampp\php\htdocs\team8.systemsUNO\laravelPBL\resources\views/participant/A008.blade.php ENDPATH**/ ?>