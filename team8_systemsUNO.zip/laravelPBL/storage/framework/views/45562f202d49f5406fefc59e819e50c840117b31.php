<!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="<?php echo e(('css/participant.css')); ?>">
        <title>A013</title>
    </head>
    <header class="header">
        <p>岡山情報ビジネス学院<br>オープンキャンパス参加者情報確認画面</p>
    </header>
    <body>
        <p><span id="messe">受付で担当の方と確認してください！</span></p>
        <form action="A013_1" method="post">
        <?php echo csrf_field(); ?>
            <p><strong>1.参加者名</strong><br>
                <input type="text" class="text" name="Name" value="<?php echo e($Name); ?>" readonly></p>

            <p><strong>2.参加学科</strong><br>
                <input type="text" class="text" name="Entry" value="<?php echo e($Entry); ?>" readonly></p>

            <p><strong>3.参加コース</strong><br>
                <input type="text" class="text" name="Course" value="<?php echo e($Course); ?>" readonly></p>

            <p><strong>4.学校情報</strong><br>
                <input type="text" class="text" name="School" value="<?php echo e($School); ?>" readonly><br></p>
                <p><input type="text" class="text" name="Department" value="<?php echo e($Department); ?>" readonly><br></p>
                <p><input type="text" class="text" name="Scyear" value="<?php echo e($Scyear); ?>" readonly></p>

            <p><strong>5.お住まいの地域</strong><br>
            <?php if($area != ''): ?>
                <input type="text" class="text" name="area" value="<?php echo e($area); ?>" readonly></p>
            <?php endif; ?>
            <?php if($area2 != ''): ?>
                <input type="text" class="text" name="area2" value="<?php echo e($area2); ?>" readonly></p>
                <?php if($area3 != ''): ?>
                    <p><input type="text" class="text" name="area3" value="<?php echo e($area3); ?>" readonly></p>
                    <!--交通費支給対象の場合-->
                    <div　id="target">
                        <p><span style="background-color: #e4e004;">
                        <font color="blue">交通費支給対象地域です。<br>案内をして下さい。&emsp;&emsp;&emsp;</fon</span></p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <?php if($judg == 1): ?>
            <!--交通費支給対象の場合-->
            <div　id="target">
                <p><span style="background-color: #e4e004;">
                <font color="blue">交通費支給対象地域です。<br>案内をして下さい。&emsp;&emsp;&emsp;</fon</span></p>
            </div>
            <?php endif; ?>
            <input type="button" onclick="history.back()" id="miss" value="訂正する">
            <input type="submit" id="last_confirm"value="確定" >
        </form>
    </body>
</html><?php /**PATH C:\xampp\php\htdocs\team8.systemsUNO\laravelPBL\resources\views/participant/A013.blade.php ENDPATH**/ ?>