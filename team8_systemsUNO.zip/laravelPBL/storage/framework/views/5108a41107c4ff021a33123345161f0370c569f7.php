<!DOCTYPE html>
<html>
    <head>
      <link rel="stylesheet" type="text/css" href="./css/teacher.css">
      <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <body>
        <h1>合否登録</h1>
        <form action="A006" method="POST"><?php echo csrf_field(); ?>
        <div id="left_table">
        <div id="left">
        <p>項目１<br>
        <?php if($items[0]->Item1): ?>
            <?php switch($items[0]->Item1):
                case (2): ?>
                <input type="radio" name="q1" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q1" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q1" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q1" value="2" class="input_r" checked="checked"> <lavel class="form_r">2</lavel class="form_r">
                <?php break; ?>
                <?php case (4): ?>
                <input type="radio" name="q1" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q1" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q1" value="4" class="input_r" checked="checked"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q1" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (6): ?>
                <input type="radio" name="q1" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q1" value="6" class="input_r" checked="checked"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q1" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q1" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (8): ?>
                <input type="radio" name="q1" value="8" class="input_r" checked="checked"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q1" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q1" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q1" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
            <?php endswitch; ?>
                
                
            </p>
            <p>項目２<br>
            <?php switch($items[0]->Item2):
                case (2): ?>
                <input type="radio" name="q2" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q2" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q2" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q2" value="2" class="input_r" checked="checked"> <lavel class="form_r">2</lavel class="form_r">
                <?php break; ?>
                <?php case (4): ?>
                <input type="radio" name="q2" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q2" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q2" value="4" class="input_r" checked="checked"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q2" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (6): ?>
                <input type="radio" name="q2" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q2" value="6" class="input_r" checked="checked"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q2" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q2" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (8): ?>
                <input type="radio" name="q2" value="8" class="input_r" checked="checked"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q2" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q2" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q2" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
            <?php endswitch; ?>
            </p>
            <p>項目３<br>
            <?php switch($items[0]->Item3):
                case (2): ?>
                <input type="radio" name="q3" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q3" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q3" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q3" value="2" class="input_r" checked="checked"> <lavel class="form_r">2</lavel class="form_r">
                <?php break; ?>
                <?php case (4): ?>
                <input type="radio" name="q3" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q3" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q3" value="4" class="input_r" checked="checked"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q3" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (6): ?>
                <input type="radio" name="q3" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q3" value="6" class="input_r" checked="checked"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q3" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q3" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (8): ?>
                <input type="radio" name="q3" value="8" class="input_r" checked="checked"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q3" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q3" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q3" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
            <?php endswitch; ?>
            </p>
            <p>項目４<br>
            <?php switch($items[0]->Item4):
                case (2): ?>
                <input type="radio" name="q4" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q4" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q4" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q4" value="2" class="input_r" checked="checked"> <lavel class="form_r">2</lavel class="form_r">
                <?php break; ?>
                <?php case (4): ?>
                <input type="radio" name="q4" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q4" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q4" value="4" class="input_r" checked="checked"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q4" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (6): ?>
                <input type="radio" name="q4" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q4" value="6" class="input_r" checked="checked"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q4" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q4" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (8): ?>
                <input type="radio" name="q4" value="8" class="input_r" checked="checked"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q4" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q4" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q4" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
            <?php endswitch; ?>
            </p>
            <p>項目５<br>
            <?php switch($items[0]->Item5):
                case (2): ?>
                <input type="radio" name="q5" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q5" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q5" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q5" value="2" class="input_r" checked="checked"> <lavel class="form_r">2</lavel class="form_r">
                <?php break; ?>
                <?php case (4): ?>
                <input type="radio" name="q5" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q5" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q5" value="4" class="input_r" checked="checked"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q5" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (6): ?>
                <input type="radio" name="q5" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q5" value="6" class="input_r" checked="checked"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q5" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q5" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                    <?php break; ?>
                <?php case (8): ?>
                <input type="radio" name="q5" value="8" class="input_r" checked="checked"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q5" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q5" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q5" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
            <?php endswitch; ?>
        <?php else: ?>
                <input type="radio" name="q1" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q1" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q1" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q1" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                <p>項目２<br>
                <input type="radio" name="q2" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q2" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q2" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q2" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                <p>項目３<br>
                <input type="radio" name="q3" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q3" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q3" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q3" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                <p>項目４<br>
                <input type="radio" name="q4" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q4" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q4" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q4" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
                <p>項目５<br>
                <input type="radio" name="q5" value="8" class="input_r"> <lavel class="form_r">8</lavel class="form_r">
                <input type="radio" name="q5" value="6" class="input_r"> <lavel class="form_r">6</lavel class="form_r">
                <input type="radio" name="q5" value="4" class="input_r"> <lavel class="form_r">4</lavel class="form_r">
                <input type="radio" name="q5" value="2" class="input_r"> <lavel class="form_r">2</lavel class="form_r">
        <?php endif; ?>
        </p>
        <p id="sum" name="sum_pass">合計：<?php echo e($items[0]->ItemSub); ?></p>
        </div>
        
        <div id="right">
            <p>不合格理由</p>
            <textarea name="Pass"><?php echo e($pass[0]->FailureMemo); ?></textarea>
        </div>
        </div>
        <div class="bottom_button"><button type='submit' value='<?php echo e($items[0]->EntrantNo); ?>' name='A006'　class="button_1">登録</button></div></form>
        <script src="../resources/js/teacher.js" ></script>
    </body>
</html><?php /**PATH C:\xampp\php\htdocs\team8.systemsUNO\laravelPBL\resources\views/teacher/A006.blade.php ENDPATH**/ ?>