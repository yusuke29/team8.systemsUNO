<!DOCTYPE html>
<html>
    <head>
    <script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <link rel="stylesheet" type="text/css" href="./css/teacher.css">
    </head>
    <body>

      <header>
        <div class="cp_navi">
          <ul>
              <li><a id="csv" herf='CSV'>CSV出力</a></li>
            
            <li><a id="approval">承認</a></li>
            <li><a href="A002">トップに戻る</a></li>

          </ul>
          </div>

          <div id="search">
          <form action="A003" method="POST"><?php echo csrf_field(); ?>
            <input type="checkbox" name="check1">名前<input type="text" style="width:110px;" name="name_search">
            <input type="checkbox" name='check2'>参加者NO<input type="text" style="width:50px;" name="no_search">
            <input type="checkbox" name='check3'>参加日<input type="date" style="width:125px;" name="data_search_1">~<input type="date" style="width:125px;" name="data_search_2">
            <input type="checkbox" name='check4'>参加学科<select name="class_search"><option></option><option>医療福祉事務学科</option><option>診療情報管理士学科</option><option>ホテル・ブライダル学科</option><option>経営アシスト学科</option><option>公務員学科</option>
            <option>公務員速修学科</option><option>保育学科</option><option>情報スペシャリスト学科</option><option>情報システム学科</option><option>ゲームクリエイター学科</option><option>ゲームプログラマー学科</option>
            <option>データマーケター学科</option><option>CGデザイン学科</option><option>ネット・動画クリエイター学科</option></select>
            <input type="checkbox" name='check5'>参加回数<select name="count_search"><option></option><option>1回</option><option>2回</option><option>3回</option><option>3回以上</option></select><br>
            <input type="checkbox" name='check6'>入試対象年度<select name="tg_search"><option><?php echo e($year[0]); ?>年</option><option><?php echo e($year[1]); ?>年</option></select>
            <input type="checkbox" name='check7'>高校<input type="text" name="sc_search">
            <button href="A003" class="reset">リセット</button>
            <button type='submit' name='search' class="search">検索</button>
          </form>
          </div>
          <div class='remove'><div class='add_button'><button id='all'>全て選択</button></div><div class='add_button'><button id="finish">終了</button></div></div>
      </header>
        <table border="1" id="participant_table">
            <tr class="th">
            <th class='remove'>承認</th>
              <th>参加日</th>
              <th>参加者NO</th>
              <th>氏名</th>
              <th>学校名</th>
              <th>学年</th>
              <th>入試対象年度</th>
              <th>参加回数</th>
              <th>参加学科</th>
              <th>コース</th>
              <th>合否</th>
              <th>詳細</th>
            </tr>
            <?php $var = 1; ?>
            <?php if($items!=""): ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="td">
                <?php $c=count($items); ?>
                <form action="A003/add" method="POST"><?php echo csrf_field(); ?><td class='remove'><input type='checkbox' class='approval_check' value="<?php echo e($item->EntrantNo); ?>" name="<?php echo e($var); ?>"></td>        
                <?php if($var===1): ?><div class='remove'><button type='submit' class="add_button" value='<?php echo e($c); ?>' name='approval'>承認</button></div><?php endif; ?>
                </form>
                  <td><?php echo e($item->Entrant); ?></td>
                  <td><?php echo e($item->EntrantNo); ?></td>
                  <td><?php echo e($item->Name); ?></td>
                  <td><?php echo e($item->School); ?></td>
                  <td><?php echo e($item->Scyear); ?></td>
                  <td><?php echo e($item->TargetAge); ?>年度</td>
                  <td><?php echo e($item->Count); ?></td>
                  <td><?php echo e($item->Entry); ?></td>
                  <td><?php echo e($item->Course); ?></td>
                  <td><form action="A003" method="POST"><?php echo csrf_field(); ?><button type='submit' value='<?php echo e($item->EntrantNo); ?>' name='registration'>登録</button></form></td>
                  <td><form action="A003" method="POST"><?php echo csrf_field(); ?><button type='submit' value='<?php echo e($item->EntrantNo); ?>' name='details'>詳細</button></form></td>
              </tr>
              <?php $var++;?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

          </table>

          
          <script src="../resources/js/teacher.js" ></script>

    </body>
</html><?php /**PATH C:\xampp\php\htdocs\team8.systemsUNO\laravelPBL\resources\views/teacher/A003.blade.php ENDPATH**/ ?>