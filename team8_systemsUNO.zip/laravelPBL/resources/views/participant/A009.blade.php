<!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="{{ ('css/participant.css') }}">
        <title>A009</title>
    </head>
    <header class="header">
        <p style="text-align:center" >岡山情報ビジネス学院<br>オープンキャンパス参加者情報入力フォーム</p>
    </header>
    <body>
        <u><p style="margin-left: 0px;margin-top: 130px; font-size: 20px;">入力を中断して近くの先生へお知らせ下さい。</p></u> 
        <p><input type="text" value="" placeholder="確認コード" id="move_code">
        <input type="submit" value="入力" id="move_confirm"></p>
    </body>
</html>