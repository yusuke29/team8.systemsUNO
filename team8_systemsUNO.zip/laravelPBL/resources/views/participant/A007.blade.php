<!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="{{ ('css/participant.css') }}">
        <title>A007</title>
    </head>
    <header class="header">
        <p>岡山情報ビジネス学院<br>オープンキャンパス参加者情報入力フォーム</p>
    </header>
    <body>
        <u><p style="margin-left: 55px;margin-top: 139px; font-size: 20px;">本日はどちらから来られましたか？</p></u>
        <div class="yn">
            <a href="/team8.systemsUNO/laravelPBL/public/A008"><button type="button" class="botton_1" id="in">県内</button></a>
            <a href="/team8.systemsUNO/laravelPBL/public/A009"><button type="button" class="botton_2" id="out">県外</button></a>
        </div>
    </body>
</html>

