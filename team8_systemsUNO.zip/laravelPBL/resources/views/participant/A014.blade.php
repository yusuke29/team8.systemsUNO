<!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="{{ ('css/participant.css') }}">
        <title>A014</title>
    </head>
    <header class="header">
        <p>岡山情報ビジネス学院<br>オープンキャンパス参加者受付番号発行画面</p>
    </header>
    <body>
        <h1 style="margin:60px">受付が完了しました！</h1>
        <div class="number">
        <p>受付番号は<span style="font-size: 70px;
                                background-color: rgb(255, 184, 92);
                                margin-left :30px;
                                margin-right :30px">{{$count}}</span>です</p>
        </div>
        <u><p><span style="font-size:large; margin: 30px;">受付の担当の方にこの番号を見せて下さい。</span></p></u>
    </body>
</html>