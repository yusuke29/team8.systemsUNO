<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="utf-8">
    <title>top</title>
    <link rel="stylesheet" type="text/css" href="css/top.css" media="all" />
</head>
<body>
    <div class="flex">
        <div class="container-1">
        <a href="A003" class="btn-border1">参加者一覧　</a>
    </div>
        <div class="container-1">
        <a href="A004" class="btn-border2"> 集計表　</a>
    </div>
    <div class="container-1">
        <a href="A001" class="btn-border3">ログアウト　</a>
    </div>

</body>
</html>
